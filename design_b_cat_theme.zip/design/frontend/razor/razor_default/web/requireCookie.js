define([
    "jquery"
],function($) {
    'use strict';
});