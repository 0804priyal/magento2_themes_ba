/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
define([
    'Magento_Ui/js/grid/columns/column',
    'Magento_Catalog/js/product/uenc-processor',
    'Magento_Catalog/js/product/list/column-status-validator'
], function (Element, uencProcessor, columnStatusValidator) {
    'use strict';

    return Element.extend({
        defaults: {
            label: ''
        },

        /**
         * Prepare data, that will be inserted as data-mage-init attribute into button. With help of this attribute
         * Add To * buttons can understand post data and urls
         *
         * @param {Object} row
         * @returns {String}
         */
        getDataMageInit: function (row) {
            console.log(row);
            return 'amquickview-link-'+row.id;
        },

        /**
         * Prepare Data-Post data that will be used in data-mage-init
         *
         * @param {Object} row
         * @return {String}
         */
        getDataPost: function (row) {
            return row.id;
        },

        /**
         * Get button label.
         *
         * @return {String}
         */
        getLabel: function () {
            console.log(window.amastyUrlQuockview);
            return window.amastyUrlQuockview;
        }
    });
});
