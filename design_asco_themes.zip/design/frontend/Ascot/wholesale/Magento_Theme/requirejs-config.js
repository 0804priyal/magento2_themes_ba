var config = {
    paths: {
        'owlcarousel': "js/owlcarousel"
    },
    shim: {
        'owlcarousel': {
            deps: ['jquery']
        }
    }
};