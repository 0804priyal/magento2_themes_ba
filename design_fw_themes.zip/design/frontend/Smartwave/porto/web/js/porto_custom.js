require([
    'jquery'
], function ($) {
    $(window).load(function() {
        setTimeout(function() {
            $('.image-link img').css('width','100%');
            $('img, object, video, embed').css('max-height','100%');
            $('img, object, video, embed').css('max-width','100%');
            $('.cms-porto_home_critterkill .critterkill_bar').css({'width': '100%', 'background-color': '#fbfbfb'});
            console.log('1411111111dkfjd');
        }, 5000);
    });
});